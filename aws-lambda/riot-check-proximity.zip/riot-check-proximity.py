import os
import json
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Attr
import haversine

AWS_SES_SENDER = os.environ["AWS_SES_SENDER"]
AWS_SES_RECIPIENT = os.environ["AWS_SES_RECIPIENT"]
AWS_REGION = os.environ["AWS_REGION_NAME"]
AWS_SES_CLIENT = boto3.client("ses", region_name=AWS_REGION)
AWS_IOT_CLIENT = boto3.client("iot-data", region_name=AWS_REGION)

def lambda_handler(event, context):
    thing_id = event["dev_id"]
    current_position = (event["position_lat"], event["position_long"])
    current_shadow = get_thing_shadow(thing_id)
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table("riot-geo-data")
    geo_points = table.scan()["Items"]
    for geo_point in geo_points:
        _distance_km = haversine.haversine(
            (geo_point["latitude"], geo_point["longitude"]),
            current_position
        )
        print("Distance (km) to:", geo_point["name"], round(_distance_km,3))
        if "current_location" not in current_shadow:
            current_shadow["current_location"] = ""
        if _distance_km < geo_point["approach_distance_km"]:
            if str(geo_point["location"]) not in str(current_shadow["current_location"]):
                send_notify_email(geo_point)

                current_shadow["current_location"] = geo_point["location"]
                update_thing_shadow(thing_id, current_shadow)

def get_thing_shadow(dev_id):
    current_shadow = json.loads(
        AWS_IOT_CLIENT.get_thing_shadow(
            thingName=dev_id
        )["payload"].read()
    )["state"]["reported"]
    print(current_shadow)
    return current_shadow

def update_thing_shadow(dev_id, data):
    reported_data = {"state": {"reported": ""}}
    reported_data["state"]["reported"] = data
    AWS_IOT_CLIENT.update_thing_shadow(
        thingName = dev_id,
        payload = json.dumps(reported_data)
    )

def send_notify_email(geo_point):
    # Send status change email
    SUBJECT = "Cool! You've arrived at: " + geo_point["name"] + "!"
    BODY_TEXT = geo_point["description"]
    BODY_HTML = """<html>
    <head></head>
    <body>
    <h1>""" + geo_point["message"] + """</h1>
    <p>""" + geo_point["description"] + """</p>
    <p>For more information visit: """ + geo_point["url"] + """</p>
    </body>
    </html>
    """
    CHARSET = "UTF-8"
    try:
        response = AWS_SES_CLIENT.send_email(
            Destination={
                "ToAddresses": [
                    AWS_SES_RECIPIENT,
                ],
            },
            Message={
                "Body": {
                    "Html": {
                        "Charset": CHARSET,
                        "Data": BODY_HTML,
                    },
                    "Text": {
                        "Charset": CHARSET,
                        "Data": BODY_TEXT,
                    },
                },
                "Subject": {
                    "Charset": CHARSET,
                    "Data": SUBJECT,
                },
            },
            Source=AWS_SES_SENDER,
        )
    except ClientError as e:
        print(e.response["Error"]["Message"])
    else:
        print("Email sent! Message ID:", response["MessageId"])
